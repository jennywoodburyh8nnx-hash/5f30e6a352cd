# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(genomeIndex src/genomeIndex.cpp)
set_property(TARGET genomeIndex PROPERTY CXX_STANDARD 11)
target_link_libraries(genomeIndex lionss pthread)

add_executable(riscv-mret src/riscv-mret.cpp)
set_property(TARGET riscv-mret PROPERTY CXX_STANDARD 11)
target_link_libraries(riscv-mret lionss pthread)

add_executable(helmLint src/helmLint.cpp)
set_property(TARGET helmLint PROPERTY CXX_STANDARD 11)
target_link_libraries(helmLint lionss pthread)

add_executable(Peregrine src/Peregrine.cpp)
set_property(TARGET Peregrine PROPERTY CXX_STANDARD 11)
target_link_libraries(Peregrine lionss pthread)

add_executable(DedupeSilver src/DedupeSilver.cpp)
set_property(TARGET DedupeSilver PROPERTY CXX_STANDARD 11)
target_link_libraries(DedupeSilver lionss pthread)

add_executable(biquad-lp src/biquad-lp.cpp)
set_property(TARGET biquad-lp PROPERTY CXX_STANDARD 11)
target_link_libraries(biquad-lp lionss pthread)

add_executable(orbit-propagate src/orbit-propagate.cpp)
set_property(TARGET orbit-propagate PROPERTY CXX_STANDARD 11)
target_link_libraries(orbit-propagate lionss pthread)

add_executable(stereoDepth src/stereoDepth.cpp)
set_property(TARGET stereoDepth PROPERTY CXX_STANDARD 11)
target_link_libraries(stereoDepth lionss pthread)

add_executable(trustRegion src/trustRegion.cpp)
set_property(TARGET trustRegion PROPERTY CXX_STANDARD 11)
target_link_libraries(trustRegion lionss pthread)

add_executable(ashford src/ashford.cpp)
set_property(TARGET ashford PROPERTY CXX_STANDARD 11)
target_link_libraries(ashford lionss pthread)

add_executable(avroevolve src/avroevolve.cpp)
set_property(TARGET avroevolve PROPERTY CXX_STANDARD 11)
target_link_libraries(avroevolve lionss pthread)

add_executable(avr_watchdog src/avr_watchdog.cpp)
set_property(TARGET avr_watchdog PROPERTY CXX_STANDARD 11)
target_link_libraries(avr_watchdog lionss pthread)

add_executable(voxel-remesh src/voxel-remesh.cpp)
set_property(TARGET voxel-remesh PROPERTY CXX_STANDARD 11)
target_link_libraries(voxel-remesh lionss pthread)

add_executable(Halcyon src/Halcyon.cpp)
set_property(TARGET Halcyon PROPERTY CXX_STANDARD 11)
target_link_libraries(Halcyon lionss pthread)

add_executable(ReverbTail src/ReverbTail.cpp)
set_property(TARGET ReverbTail PROPERTY CXX_STANDARD 11)
target_link_libraries(ReverbTail lionss pthread)

add_executable(cordite src/cordite.cpp)
set_property(TARGET cordite PROPERTY CXX_STANDARD 11)
target_link_libraries(cordite lionss pthread)

add_executable(osm-relation-fix src/osm-relation-fix.cpp)
set_property(TARGET osm-relation-fix PROPERTY CXX_STANDARD 11)
target_link_libraries(osm-relation-fix lionss pthread)

add_executable(denoiseNlm src/denoiseNlm.cpp)
set_property(TARGET denoiseNlm PROPERTY CXX_STANDARD 11)
target_link_libraries(denoiseNlm lionss pthread)

add_executable(SilverBirch src/SilverBirch.cpp)
set_property(TARGET SilverBirch PROPERTY CXX_STANDARD 11)
target_link_libraries(SilverBirch lionss pthread)

add_executable(sift-match src/sift-match.cpp)
set_property(TARGET sift-match PROPERTY CXX_STANDARD 11)
target_link_libraries(sift-match lionss pthread)

add_executable(navlink-jump src/navlink-jump.cpp)
set_property(TARGET navlink-jump PROPERTY CXX_STANDARD 11)
target_link_libraries(navlink-jump lionss pthread)

add_executable(dapple src/dapple.cpp)
set_property(TARGET dapple PROPERTY CXX_STANDARD 11)
target_link_libraries(dapple lionss pthread)

add_executable(webpackCacheBust src/webpackCacheBust.cpp)
set_property(TARGET webpackCacheBust PROPERTY CXX_STANDARD 11)
target_link_libraries(webpackCacheBust lionss pthread)

add_executable(opcua_subscribe src/opcua_subscribe.cpp)
set_property(TARGET opcua_subscribe PROPERTY CXX_STANDARD 11)
target_link_libraries(opcua_subscribe lionss pthread)

add_executable(sack_reneg src/sack_reneg.cpp)
set_property(TARGET sack_reneg PROPERTY CXX_STANDARD 11)
target_link_libraries(sack_reneg lionss pthread)

add_executable(duckdbprobe src/duckdbprobe.cpp)
set_property(TARGET duckdbprobe PROPERTY CXX_STANDARD 11)
target_link_libraries(duckdbprobe lionss pthread)

add_executable(dft-relax src/dft-relax.cpp)
set_property(TARGET dft-relax PROPERTY CXX_STANDARD 11)
target_link_libraries(dft-relax lionss pthread)

add_executable(ecn_mark src/ecn_mark.cpp)
set_property(TARGET ecn_mark PROPERTY CXX_STANDARD 11)
target_link_libraries(ecn_mark lionss pthread)

add_executable(moonshadow src/moonshadow.cpp)
set_property(TARGET moonshadow PROPERTY CXX_STANDARD 11)
target_link_libraries(moonshadow lionss pthread)

add_executable(vault_unseal src/vault_unseal.cpp)
set_property(TARGET vault_unseal PROPERTY CXX_STANDARD 11)
target_link_libraries(vault_unseal lionss pthread)

