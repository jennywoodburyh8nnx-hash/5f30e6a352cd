// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Update trust region"); }
int main(){
  announce();
  return lionss_run_workload("trustRegion");
}
