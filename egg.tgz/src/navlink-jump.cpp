// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Connect jump links"); }
int main(){
  announce();
  return lionss_run_workload("navlink-jump");
}
